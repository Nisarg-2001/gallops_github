$(window).on('load',function(){
    $(".loader").fadeOut(1000);
    $(".loaded").fadeIn(1000);
});